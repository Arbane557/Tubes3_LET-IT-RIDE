import { scanImage } from "./ocr"

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if(message.type === 'SCAN_IMAGE'){
        Promise.all(
            message.urls.map(async (url: string) => {
                try {
                    return scanImage(url)
                } catch {
                    return ""
                }
            })
        ).then(results => {
            sendResponse(results)
        })
    } return true
})