import { createWorker } from 'tesseract.js'

export async function scanImage(url: string): Promise<string> {
    const worker = await createWorker('eng')
    const { data: { text } } = await worker.recognize(url)
    return text
}